# BOX_2 > 2023-09-26 7:52am
https://universe.roboflow.com/1-vwkjn/box_2-j9cqi

Provided by a Roboflow user
License: Public Domain

